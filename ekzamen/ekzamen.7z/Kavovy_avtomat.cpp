#include "Kavovy_avtomat.h"




Kavovy_avtomat::Kavovy_avtomat(int water, int sugar, int milk, int tea, int coffe, int cappucino):Napiy(0,water,sugar,milk)
{
	this->tea.setnumbOfDrink(tea);
	this->coffe.setnumbOfDrink(coffe);
	this->capuccino.setnumbOfDrink(cappucino);
}

Kavovy_avtomat::~Kavovy_avtomat()
{
}

void Kavovy_avtomat::AddIngridients()
{
	int choice;
	cout << "Choose what to add:\n";
	cout << "1 - Water\n";
	cout << "2 - Sugar\n";
	cout << "3 - Milk\n";
	cout << "4 - Tea\n";
	cout << "5 - Coffee\n";
	cout << "6 - Cappucino\n";
	cin >> choice;
	switch (choice)
	{
	case 1:
	{
		this->water += AdeOneIngrid();
		break;
	}
	case 2:
	{
		this->sugar+= AdeOneIngrid();
		break;
	}
	case 3:
	{
		this->sugar += AdeOneIngrid();
		break;
	}
	case 4:
	{
		tea.setnumbOfDrink(tea.getnumbOfDrink() + AdeOneIngrid());
		break;
	}
	case 5:
	{
		coffe.setnumbOfDrink(coffe.getnumbOfDrink() + AdeOneIngrid());
		break;
	}
	case 6:
	{
		capuccino.setnumbOfDrink(capuccino.getnumbOfDrink() + AdeOneIngrid());
		break;
	}
	default:
		break;
	}
}

void Kavovy_avtomat::ChangePrice()
{
	int choice, price;
	cout << "Choose drink to change price:\n";
	cout << "1 - Tea\n";
	cout << "2 - Coffee\n";
	cout << "3 - Cappucino\n";
	cin >> choice;
	cout << "Cout enter price:\n";
	cin >> price;
	switch (choice)
	{
	case 1:
	{
		tea.SetMoney(price);
		break;
	}
	case 2:
	{
		coffe.SetMoney(price);
		break;
	}
	case 3:
	{
		capuccino.SetMoney(price);
		break;
	}
	default:
		break;
	}
}



int Kavovy_avtomat::AdeOneIngrid()
{
	int ingridient;
	cout << "Enter how much to add:";
	cin >> ingridient;
	return ingridient;
}

void Kavovy_avtomat::Menu()
{
	int choice;
	cout << "Welcom to Drink AUTOMAT 2042\n";
	cout << "1 - Order a drink\n";
	cout << "2 - Login as admin\n";
	cin >> choice;
	switch (choice)
	{
	case 1:
	{
		break;
	}
	case 2:
	{
		break;
	}
	default:
		break;
	}
}

void Kavovy_avtomat::UserMenu()
{
	int choice, price;
	cout << "Choose drink to change price:\n";
	cout << "1 - Tea\n";
	cout << "2 - Coffee\n";
	cout << "3 - Cappucino\n";
	cin >> choice;
	
}

void Kavovy_avtomat::Prodaj(Napiy * napiy)
{
	if (!CanCook(napiy))
		return;

	this->milk -= napiy->getMilk();
	this->sugar-= napiy->getSugar();
	this->water -= napiy->getWater();
	switch (napiy->getType())
	{
	case TEA:
	{
		tea.getnumbOfDrink()
		break;
	}
	case COFFE:
		break;
	case CAPUCCINO:
		break;
	default:
		break;
	}
}



Tea::Tea(int price = 5, int water = 2, int sugar = 1, int milk = 0) :Napiy(price, water, sugar, milk)
{
}




void Tea::SetName()
{
	this->name = TEA;
}

string Tea::getName() const
{
	return "Tea";
}

Tea::~Tea()
{
}

Napiy::Napiy(int price, int water, int sugar, int milk):money(price), water(water), sugar(sugar), milk(milk)
{
}

Napiy::~Napiy()
{
}

bool Napiy::CanCook(Napiy * napiy) const
{
	if(this->water < napiy->getWater()
		|| this->sugar< napiy->getSugar()
		|| this->milk < napiy->getMilk() 
		|| this->numbOfDrink < napiy->getnumbOfDrink())
		return false;
	return true;
}

void Napiy::SetMoney(int price)
{
	this->money = price;
}

void Napiy::setMilk(int milk)
{
	this->milk = milk;
}

void Napiy::setWater(int water)
{
	this->water = water;
}

void Napiy::setSugar(int sugar)
{
	this->sugar = sugar;
}

void Napiy::setnumbOfDrink(int drink)
{
	this->numbOfDrink = drink;
}

int Napiy::getMoney() const
{
	return money;
}

int Napiy::getWater() const
{
	return water;
}

int Napiy::getSugar() const
{
	return sugar;
}

int Napiy::getMilk() const
{
	return milk;
}

int Napiy::getnumbOfDrink() const
{
	return numbOfDrink;
}

type Napiy::getType() const
{
	return name;
}

Coffe::Coffe(int price = 7, int water = 1, int sugar = 2, int milk = 0) :Napiy(price, water, sugar, milk)
{
}

void Coffe::SetName()
{
	this->name = COFFE;
}

string Coffe::getName() const
{
	return "Coffe";
}

Coffe::~Coffe()
{
}

Kapucino::Kapucino(int price = 10, int water = 2, int sugar = 2, int milk= 1) :Napiy(price, water, sugar, milk)
{
}

void Kapucino::SetName()
{
	this->name = CAPUCCINO;
}

string Kapucino::getName() const
{
	return "Cappucino";
}

Kapucino::~Kapucino()
{
}
