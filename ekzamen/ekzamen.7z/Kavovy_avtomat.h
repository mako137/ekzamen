#pragma once
#include<iostream>
#include<string>
using namespace std;
enum type { TEA, COFFE, CAPUCCINO};

class Napiy
{
public:
	Napiy(int price, int water, int sugar, int milk);
	virtual ~Napiy();
	bool CanCook(Napiy *)const;
	virtual void SetName() = 0;
	void SetMoney(int price);
	void setMilk(int milk);
	void setWater(int water);
	void setSugar(int sugar);
	void setnumbOfDrink(int drink);

	virtual string getName() const = 0;
	int getMoney() const;
	int getWater() const;
	int getSugar() const;
	int getMilk() const;
	int getnumbOfDrink() const;
	type getType()const;

protected:
	type name;
	int numbOfDrink;
	int money;
	int water;
	int sugar;
	int milk;
};

class Tea:public Napiy
{
public:
	Tea(int price, int water, int sugar, int milk);
	virtual void SetName();
	virtual string getName() const;
	~Tea();
};
class Coffe:public Napiy
{
public:
	Coffe(int price, int water, int sugar, int milk);
	virtual void SetName();
	virtual string getName() const;
	~Coffe();
};

class Kapucino:public Napiy
{
public:
	Kapucino(int price, int water, int sugar, int milk);
	virtual void SetName();
	virtual string getName() const;
	~Kapucino();
};
class Kavovy_avtomat:public Napiy
{
public:
	Kavovy_avtomat(int water, int sugar, int milk, int tea, int coffe, int cappucino);
	~Kavovy_avtomat();
	void AddIngridients();
	void ChangePrice();
	int AdeOneIngrid();
	void Menu();
	void UserMenu();
	void AdminMenu();
	bool isAdmin();
	void Prodaj(Napiy* napiy);
private:
	Tea tea;
	Kapucino capuccino;
	Coffe coffe;
};

