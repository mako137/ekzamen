#include<set>
#include<map>
#include<iostream>
#include<string>
#include<algorithm>
using namespace std;
//using std::pair<int,string>;

int main()
{

	map<int,string> cities =
	{
		{33000, "Rivne"},
		{86400,"Mykolaiv"},
		{31400,"Lviv"}	
	};

	for (auto & temp: cities)
	{
		cout << temp.first << "  " << temp.second << endl;
	}
	
	//cout << cities.at(33) << endl;
	cout << cities[33000] << endl;
	cities[33000] = "ABS";
	for (auto & temp : cities)
	{
		cout << temp.first << "  " << temp.second << endl;
	}
	multimap<int,string> citys = 
	{
	{33000, "Rivne"},
	{33000, "Rivne"},
	{33000, "Rivne"},
	{86400,"Mykolaiv"},
	{31400,"Lviv"}
	};

	cout << endl;
	for (auto & temp : citys)
	{
		cout << temp.first << "  " << temp.second << endl;
	}
	citys.insert(make_pair(1000, "qwe"));

	cout << endl;

	for (auto & temp : citys)
	{
		cout << temp.first << "  " << temp.second << endl;
	}

	cout << "__" << endl;
	for (auto i = citys.rbegin(); i != citys.rend(); i++)
	{
		cout << i->first << " " << i->second << endl;
	}

	auto iter = citys.find(86400);
	if (iter != citys.end())
		cout << iter->first << " " << iter->second << endl;
	system("pause");
}

//ostream &operator << (ostream & in, Pair & p)